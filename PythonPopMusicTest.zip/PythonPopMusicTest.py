"""
Program: PythonPopMusicTest
Author: Matthew Hayden
Last Date Modified: 5/7/2022
The purpose of this program is to ask the user what their three favorite pop artists are.
Once the user has inputted them, a new window displays listing the artists they enterred, their respective genre, and three 'suggested' artists that are similar to each one.
Also includes another window that lists all the valid inputs the user may enter.
"""

from tkinter import *
from PIL import ImageTk,Image
from tkinter import messagebox
import random

class Frames(object):

    """
    Callback function that closes all the windows.
    It checks each of the three windows to see if they are open and closes them if so.
    """
    def exitWindows(self):
        if master is not None and master.winfo_exists():
            master.destroy()
        if windowThree is not None and windowThree.winfo_exists():
            windowThree.destroy()
        if windowTwo is not None and windowTwo.winfo_exists():
            windowTwo.destroy()

    """
    This function opens up the third window, the results. Many loops are gone through to either verify that the correct inputs were given or to determine what genre the inputted artists are.
    The window itself has a grid layout where it displays the artists the user inputted, their respective genre, and three 'suggested' artists that fall within the same genre.
    """
    def openNewWindow(self):
        mainPopArtists=["Taylor Swift", "Justin Bieber", "Katy Perry", "Harry Styles", "The Weeknd", "Selena Gomez", "Lady Gaga", "Britney Spears", "Ariana Grande", "Rihanna", "Adele", "Dua Lipa"] #'Mainstream' pop artist list that is later used to check whether the inputted artists are of the 'Mainstream' genre.
        indiePopArtists=["Billie Eilish", "MGMT", "Lorde", "Poppy", "Carly Rae Jepsen", "Charli XCX","Empire of the Sun",  "The Neighbourhood", "Gorillaz", "Grimes", "Lana Del Rey", "Marina", "Tame Impala", "Beach House"] #'Indie' pop artist list that is later used to check whether the inputted artists are of the 'Indie' genre.
        originalPopArtistList=self.popArtistList #Copies the 'popArtistList' to a new one simply so that 'self' does not have to be passed whenever the list is called.
        windowTwo = Toplevel()
        windowTwo.title("Results")
        windowTwo.geometry("550x395+1130+300")
        windowTwo.resizable(False, False)
        popArtistOne=self.entryOne.get() #Copies the first inputted artist to a new variable simply so that 'self' does not have to be passed whenever the entry is needed.
        popArtistTwo=self.entryTwo.get() #Copies the second inputted artist to a new variable simply so that 'self' does not have to be passed whenever the entry is needed.
        popArtistThree=self.entryThree.get() #Copies the third inputted artist to a new variable simply so that 'self' does not have to be passed whenever the entry is needed.

        """
        Series of 'if' statements to validate user inpute.
        The first three 'if' statements make sure that the user inputted a valid artist.
        The second three 'if' statements makes sure that the user did not input the same artist two or more times.
        """
        if popArtistOne not in originalPopArtistList:
            windowTwo.destroy()
            messagebox.showerror("Error","First entry is invalid.")
        elif popArtistTwo not in originalPopArtistList:
            windowTwo.destroy()
            messagebox.showerror("Error","Second entry is invalid.")
        elif popArtistThree not in originalPopArtistList:
            windowTwo.destroy()
            messagebox.showerror("Error","Third entry is invalid.")
        elif popArtistOne == popArtistTwo:
            windowTwo.destroy()
            messagebox.showerror("Error","Cannot have two identical entries.")
        elif popArtistOne == popArtistThree:
            windowTwo.destroy()
            messagebox.showerror("Error","Cannot have two identical entries.")
        elif popArtistTwo == popArtistThree:
            windowTwo.destroy()
            messagebox.showerror("Error","Cannot have two identical entries.")
        else:
            pass
        
        newMainPopList=[] #Initializes a new 'mainstream' pop list that is filled by the first following 'for' loop.
        newIndiePopList=[] #Initializes a new 'indie' pop list that is filled by the second following 'for' loop.
        
        """
        Two 'for' loops that create two lists, one for 'mainstream' artists and one for 'indie' artists.
        The 'if' statements make sure that the artists the user inputted do not get put into the new lists.
        This is done so that the inputted artists by the user are not given as 'suggested' artists.
        """
        for mainPopArtist in mainPopArtists:
            if mainPopArtist != popArtistOne and mainPopArtist != popArtistTwo and mainPopArtist != popArtistThree:
                newMainPopList.append(mainPopArtist)
        for indiePopArtist in indiePopArtists:
            if indiePopArtist != popArtistOne and indiePopArtist != popArtistTwo and indiePopArtist != popArtistThree:
                newIndiePopList.append(indiePopArtist)

        """
        Series of 'for' loops that check whether each inputted artist is 'Mainstream' or 'Indie'
        """
        for x in mainPopArtists:
            if popArtistOne in x:
                popArtistOneGenre = "Mainstream"
        for x in indiePopArtists:
            if popArtistOne in x:
                popArtistOneGenre = "Indie"
        for x in mainPopArtists:
            if popArtistTwo in x:
                popArtistTwoGenre = "Mainstream"
        for x in indiePopArtists:
            if popArtistTwo in x:
                popArtistTwoGenre = "Indie"
        for x in mainPopArtists:
            if popArtistThree in x:
                popArtistThreeGenre = "Mainstream"
        for x in indiePopArtists:
            if popArtistThree in x:
                popArtistThreeGenre = "Indie"
                
        popArtistOneSuggested=[] #Intializes a list that will be filled with three random artists, depending on whether the user's first entry was 'Mainstream' or 'Indie'
        popArtistTwoSuggested=[] #Intializes a list that will be filled with three random artists, depending on whether the user's second entry was 'Mainstream' or 'Indie'
        popArtistThreeSuggested=[] #Intializes a list that will be filled with three random artists, depending on whether the user's third entry was 'Mainstream' or 'Indie'
        
        """
        Series of 'if' statements to check what genre each entry is.
        The preinitialized lists are then filled accordingly.
        """
        if popArtistOneGenre == "Mainstream":
            popArtistOneSuggested = random.sample(newMainPopList,3)
        elif popArtistOneGenre == "Indie":
            popArtistOneSuggested = random.sample(newIndiePopList,3)
        if popArtistTwoGenre == "Mainstream":
            popArtistTwoSuggested = random.sample(newMainPopList,3)
        elif popArtistTwoGenre == "Indie":
            popArtistTwoSuggested = random.sample(newIndiePopList,3)
        if popArtistThreeGenre == "Mainstream":
            popArtistThreeSuggested = random.sample(newMainPopList,3)
        elif popArtistThreeGenre == "Indie":
            popArtistThreeSuggested = random.sample(newIndiePopList,3)
            
        """
        Simple formatting. First, the column titles are formatted.
        Next, the three pop artists the user inputted are listed in the first column.
        Third, each artists' respective genre is listed in the second column.
        Finally, the suggested artists are listed in the third column.
        """
        artistLabel= Label(windowTwo,font='Helvetica 9 bold',width =25, height=6, borderwidth = 1,relief="solid", text=("Artist")).grid(row=0,column=1,padx=2,pady=2)
        genreLabel= Label(windowTwo,font='Helvetica 9 bold',width =25, height=6, borderwidth = 1,relief="solid", text=("Genre")).grid(row=0,column=2,padx=2,pady=2)
        similarArtistLabel= Label(windowTwo,font='Helvetica 9 bold',width =25, height=6, borderwidth = 1,relief="solid", text=("Similar Artists")).grid(row=0,column=3,padx=2,pady=2)
        
        popArtistOneLabel = Label(windowTwo, width =25, height=6,borderwidth = 1,relief="solid", text=popArtistOne).grid(row=1,column=1,padx=2,pady=2)
        popArtistTwoLabel = Label(windowTwo, width =25, height=6,borderwidth = 1,relief="solid",text=popArtistTwo).grid(row=2,column=1,padx=2,pady=2)
        popArtistThreeLabel = Label(windowTwo, width =25, height=6,borderwidth = 1,relief="solid", text=popArtistThree).grid(row=3,column=1,padx=2,pady=2)
        
        popArtistOneGenreLabel = Label(windowTwo, width =25, height=6,borderwidth = 1,relief="solid", text=popArtistOneGenre).grid(row=1,column=2,padx=2,pady=2)
        popArtistTwoGenreLabel = Label(windowTwo, width =25, height=6,borderwidth = 1,relief="solid", text=popArtistTwoGenre).grid(row=2,column=2,padx=2,pady=2)
        popArtistThreeGenreLabel = Label(windowTwo, width =25, height=6,borderwidth = 1,relief="solid", text=popArtistThreeGenre).grid(row=3,column=2,padx=2,pady=2)
        
        popArtistOneSuggestedLabelBox = Label(windowTwo, width =25, height=6,borderwidth = 1,relief="solid", text="").grid(row=1,column=3,padx=2,pady=2)
        popArtistTwoSuggestedLabelBox = Label(windowTwo, width =25, height=6,borderwidth = 1,relief="solid", text="").grid(row=2,column=3,padx=2,pady=2)
        popArtistThreeSuggestedLabelBox = Label(windowTwo, width =25, height=6,borderwidth = 1,relief="solid", text="").grid(row=3,column=3,padx=2,pady=2)
        
        artistOneSuggesteds=popArtistOneSuggested
        text1=Text(windowTwo, width = 16, height = 5,font='Helvetica, 9', bg='#F0F0ED',relief="flat")
        text1.grid(row=1,column=3,padx=2,pady=2)
        for artistOneSuggested in artistOneSuggesteds:
            text1.insert(END,artistOneSuggested + '\n'+'\n')
        
        artistTwoSuggesteds=popArtistTwoSuggested
        text2=Text(windowTwo, width = 16, height = 5,font='Helvetica, 9', bg='#F0F0ED',relief="flat")
        text2.grid(row=2,column=3,padx=2,pady=2)
        for artistTwoSuggested in artistTwoSuggesteds:
            text2.insert(END,artistTwoSuggested + '\n'+'\n')

        artistThreeSuggesteds=popArtistThreeSuggested
        text3=Text(windowTwo, width = 16, height = 5,font='Helvetica, 9', bg='#F0F0ED',relief="flat")
        text3.grid(row=3,column=3,padx=2,pady=2)
        for artistThreeSuggested in artistThreeSuggesteds:
            text3.insert(END,artistThreeSuggested + '\n'+'\n')

    """
    This function opens up the second window, the artist list.
    First, the basic window formatting is done.
    Second, three images are defined and inserted into the bottom of the window.
    Finally, the window is populated with a list of the artists that are allowed to be inputted.
    """
    def openArtistList(self):
        windowThree = Toplevel()
        windowThree.title("Pop Artist List")
        windowThree.geometry("250x475+250+300")
        windowThree.resizable(False, False)

        image3 = Image.open("TaylorSwift.png")
        resize_image3=image3.resize((50,50))
        photo3 = ImageTk.PhotoImage(resize_image3)
        img_label3 = Label(windowThree,image=photo3)
        img_label3.image = photo3
        img_label3.place(x=25,y=420)
        
        image4 = Image.open("LanaDel.jpg")
        resize_image4=image4.resize((50,50))
        photo4 = ImageTk.PhotoImage(resize_image4)
        img_label4 = Label(windowThree,image=photo4)
        img_label4.image = photo4
        img_label4.place(x=100,y=420)

        image2 = Image.open("TameImpala.jpg")
        resize_image2=image2.resize((50,50))
        photo2 = ImageTk.PhotoImage(resize_image2)
        img_label2 = Label(windowThree,image=photo2)
        img_label2.image = photo2
        img_label2.place(x=175,y=420)
        
        artists=self.popArtistList #The pop artist list is copied to a new variable, 'artists'. The artists are then printed out vertically, one on each line.
        text=Text(windowThree, width = 30, height = 26)
        text.pack()
        for artist in artists:
            text.insert(END, artist +'\n')

    """
    The first window the user sees.
    Places a background photo within the window.
    Contains the three labels telling the user to enter a valid pop artist, as well as entry boxes below each respective label.
    Contains all the buttons that lead to the other two windows as well as the button to close all the windows.
    Majority of this function is dedicated to formatting.
    """
    def windowOne(self,master):
        master.title("Top three pop artists")
        master.geometry("630x630+500+300")
        master.resizable(False, False)

        image1 = Image.open("CarlyRae.jpg")
        photo = ImageTk.PhotoImage(image1)
        img_label = Label(master, image=photo)
        img_label.image = photo
        img_label.place(x=0,y=0)

        self.entryOne = StringVar() #'self.entryOne' is initialized to 'StringVar()' so that the first entry is handled correctly.
        self.entryTwo = StringVar() #'self.entryTwo' is initialized to 'StringVar()' so that the second entry is handled correctly.
        self.entryThree = StringVar() #'self.entryThree' is initialized to 'StringVar()' so that the third entry is handled correctly.
        self.popArtistList=["Adele", "Ariana Grande", "Beach House", "Billie Eilish", "Britney Spears", "Carly Rae Jepsen", "Charli XCX", "Dua Lipa", "Empire of the Sun", "Gorillaz", "Grimes", "Harry Styles", "Justin Bieber", "Katy Perry",
                            "Lady Gaga", "Lana Del Rey", "Lorde", "Marina", "MGMT", "Rihanna", "Poppy", "Selena Gomez", "Tame Impala", "Taylor Swift", "The Neighbourhood", "The Weeknd" ] #Defines the list of valid pop artists the user may enter.

        """
        Basic formatting.
        Fist, the three pop artist labels are formatted.
        Second, the three respective pop artist entry boxes are formatted.
        Third, the three buttons are formatted.
        Finally, all the labels, entry boxes, and buttons are unpacked or placed.
        """
        popArtistOneLabel = Label(text="Who is your favorite pop artist?", foreground="black",background="white",width=30,height=1)
        popArtistTwoLabel = Label(text="Who is your second favorite pop artist?",foreground="black",background="white",width=30,height=1)
        popArtistThreeLabel = Label(text="Who is your third favorite pop artist?",foreground="black",background="white",width=30,height=1)

        popArtistOneEntry = Entry(master, borderwidth=3,relief="sunken", textvariable=self.entryOne)
        popArtistTwoEntry = Entry(master, borderwidth=3,relief="sunken", textvariable=self.entryTwo)
        popArtistThreeEntry = Entry(master, borderwidth=3,relief="sunken", textvariable=self.entryThree)

        popArtistListButton = Button(master,borderwidth=5,relief="raised", text = "Click to view a list of supported pop artists", command = self.openArtistList) #Button that takes the user to window three where they can view a list of the support pop artists to be inputted. Calls back to 'openArtistList'
        windowOneButton = Button(master,borderwidth=5,relief="raised", text = "Click to submit", command = self.openNewWindow) #Button that takes the user to window two where they can view information related to their entries. Calls back to 'openNewWindow'
        exitWindowsButton = Button(master, borderwidth=5,relief="raised", text = "Click to close all windows", command = self.exitWindows) #Button to close all windows that are open. Calls back to 'exitWindows'
        
        popArtistListButton.pack()
        popArtistOneLabel.pack()
        popArtistOneEntry.pack()
        popArtistTwoLabel.pack()
        popArtistTwoEntry.pack()
        popArtistThreeLabel.pack()
        popArtistThreeEntry.pack()
        windowOneButton.pack()
        exitWindowsButton.place(x=240, y=590)


master = Tk()
app = Frames()
app.windowOne(master)
master.mainloop()
